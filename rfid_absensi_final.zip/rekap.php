<?php include 'db.php'; if (!isset($_SESSION['login'])) die("Login dulu");
$res = $conn->query("SELECT a.*, s.nama FROM absensi a JOIN siswa s ON a.id_siswa = s.id ORDER BY a.id DESC LIMIT 100"); ?>
<!DOCTYPE html><html><head><link rel="stylesheet" href="assets/style.css"><title>Rekap Absensi</title></head>
<body><?php include 'navbar.php'; ?><div class="container"><h2>Riwayat Absensi</h2>
<table><tr><th>Nama</th><th>Tanggal</th><th>Waktu</th></tr>
<?php while($r=$res->fetch_assoc()): ?>
<tr><td><?= $r['nama'] ?></td><td><?= $r['tanggal'] ?></td><td><?= $r['waktu'] ?></td></tr>
<?php endwhile; ?>
</table></div></body></html>
