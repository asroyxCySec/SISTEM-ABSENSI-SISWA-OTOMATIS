<div class="navbar">
  <a href="dashboard.php">Dashboard (<?= $_SESSION['role'] ?>)</a>
  <?php if ($_SESSION['role'] === 'admin'): ?>
    <a href="akun.php">Kelola Akun</a>
  <?php endif; ?>
  <a href="siswa.php">Data Siswa</a>
  <a href="rekap.php">Rekap</a>
  <a href="logout.php">Logout</a>
</div>
