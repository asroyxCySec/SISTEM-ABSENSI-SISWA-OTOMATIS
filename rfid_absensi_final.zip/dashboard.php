<?php include 'db.php'; if (!isset($_SESSION['login'])) header('Location: login.php'); ?>
<!DOCTYPE html><html><head><link rel="stylesheet" href="assets/style.css"><title>Dashboard</title></head>
<body><?php include 'navbar.php'; ?>
<div class="container"><h2>Selamat datang di Sistem Absensi</h2></div></body></html>
