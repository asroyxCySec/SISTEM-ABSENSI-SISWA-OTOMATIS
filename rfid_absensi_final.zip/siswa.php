<?php include 'db.php'; if (!isset($_SESSION['login'])) die("Login dulu");
if (isset($_POST['tambah'])) {
  $conn->query("INSERT INTO siswa (nama, uid, no_wa) VALUES ('{$_POST['nama']}', '{$_POST['uid']}', '{$_POST['no_wa']}')");
}
$result = $conn->query("SELECT * FROM siswa"); ?>
<!DOCTYPE html><html><head><link rel="stylesheet" href="assets/style.css"><title>Data Siswa</title></head>
<body><?php include 'navbar.php'; ?><div class="container"><h2>Data Siswa</h2>
<form method="post">
<input name="nama" placeholder="Nama" required>
<input name="uid" placeholder="UID RFID" required>
<input name="no_wa" placeholder="No WhatsApp" required>
<button name="tambah">Tambah</button>
</form>
<table><tr><th>Nama</th><th>UID</th><th>No WA</th></tr>
<?php while($row=$result->fetch_assoc()): ?>
<tr><td><?= $row['nama'] ?></td><td><?= $row['uid'] ?></td><td><?= $row['no_wa'] ?></td></tr>
<?php endwhile; ?>
</table></div></body></html>
