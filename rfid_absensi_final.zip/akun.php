<?php include 'db.php'; if ($_SESSION['role'] !== 'admin') die("Akses ditolak");
if (isset($_POST['tambah'])) {
  $conn->query("INSERT INTO akun (username, password, role) VALUES ('{$_POST['username']}', '{$_POST['password']}', '{$_POST['role']}')");
}
$result = $conn->query("SELECT * FROM akun"); ?>
<!DOCTYPE html><html><head><link rel="stylesheet" href="assets/style.css"><title>Kelola Akun</title></head>
<body><?php include 'navbar.php'; ?><div class="container"><h2>Kelola Data Akun</h2>
<form method="post">
<input name="username" placeholder="Username" required>
<input name="password" placeholder="Password" required>
<select name="role"><option value="admin">Admin</option><option value="guru">Guru</option></select>
<button name="tambah">Tambah</button>
</form>
<table><tr><th>Username</th><th>Role</th></tr>
<?php while($row=$result->fetch_assoc()): ?>
<tr><td><?= $row['username'] ?></td><td><?= $row['role'] ?></td></tr>
<?php endwhile; ?>
</table></div></body></html>
